﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            {
                switch (comboBox2.SelectedIndex)
                {
                    case 0:
                        MessageBox.Show("Hola super humano vamos a seleccionar la pestaña sumatoria");
                        break;
                    case 1:
                        MessageBox.Show("Hola super humano vamos a seleccionar la pestaña tabla");
                        tabControl1.SelectedTab = tabPage2;
                        break;
                    case 2:
                        MessageBox.Show("Hola super humano vamos a seleccionar la pestaña Nùmero Perfecto");
                        tabControl1.SelectedTab = tabPage3;
                        break;
                }
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int p = 0, su = 0;
            int q = Convert.ToInt32(textBox4.Text);
            do
            {
                p++;
                su = su + p;

            } while (p < q);

            textBox3.Text = su.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(comboBox3.Text);
            int mul = 0;

            for (int y = 0; y <= 10; y++)
            {

                mul = x * y;
                listBox1.Items.Add(x + "*" + y + "=" + mul);

            }
        }

        private void multi_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(comboBox5.Text);
            int su = 0;
            int div = x;
            do
            {
                su++;
                div = x % su;
                if (div == 0 && !(su == x))
                {
                    listBox2.Items.Add(su + ",");
                }

            } while (su < x);
            

        }
    }
}



     
       
