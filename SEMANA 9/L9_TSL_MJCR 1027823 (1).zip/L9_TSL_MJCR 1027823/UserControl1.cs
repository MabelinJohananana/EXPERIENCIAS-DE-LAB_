﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

{
    public partial class UserControl1: UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        Automovil myAutomovil = new Automovil();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BTN_info_Click(object sender, EventArgs e)
        {

            //obtener lo que está en la caja de texto y se guarda en la clase
            myAutomovil.DefinirPrecio (Convert.ToDouble(TXT_precio.Text));
            myAutomovil.DefinirModelo (Convert.ToInt32(TXT_modelo.Text));
            myAutomovil.DefinirMarca (TXT_marca.Text);
            myAutomovil.DefinirTipoCambio (Convert.ToDouble(TXT_tcambio.Text)); 

            MessageBox.Show("Los datos se guardaron exitosamente :)");
            tabControl1.SelectedTab = Datos_auto;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void BTN_aplicar_Click(object sender, EventArgs e)
        {
            myAutomovil.AplicarDescuento(Convert.ToDouble(TXT_descuento.Text));
            string cadena = ($"Marca: {TXT_marca}. \nModelo: {TXT_modelo}. \nPrecio: {TXT_precio}. \nPrecio en dólares: {myAutomovil.Conversion()}. \nDisponibilidad: {myAutomovil.MostrarDisponibilidad()}");
            textBox1.Text = cadena;
        }
    }
}
