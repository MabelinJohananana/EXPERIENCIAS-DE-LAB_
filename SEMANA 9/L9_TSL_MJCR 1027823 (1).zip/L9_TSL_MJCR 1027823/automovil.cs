﻿
{
    public class Automovil
    {
        public int modelo; 
        private double precio;
        private double tipoCambioDolar;
        public string marca;
        private bool disponible;
        private double descuentoAplicado; 

                 
        public int Modelo { get { return modelo; } }
        public double Precio { get { return precio; } }
        public double TipoCambioDolar { get { return tipoCambioDolar; } }
        public string Marca { get { return marca; } }
        //public bool disponible;
        public double DescuentoAplicado { get { return descuentoAplicado; } }
        //public void automovil;


        //constructor 
        public Automovil()
        {
            modelo = 2019;
            precio = 1000.00;
            marca = "";
            disponible = false;
            tipoCambioDolar = 7.50;
            descuentoAplicado = 0.00;
        }

        public void DefinirModelo(int unModelo)
        {
            modelo = unModelo;
        }
        public void DefinirPrecio(double unPrecio)
        {
            precio = unPrecio;
        }
        public void DefinirMarca(string unaMarca)
        {
            marca = unaMarca;
        }

        public void DefinirTipoCambio(double unTipoCambioDolar)
        {
            tipoCambioDolar = unTipoCambioDolar;
        }

        public void CambiarDisponibilidad()
        {
            if (disponible)
            {
                disponible = false;
            }
            else
            {
                disponible = true;
            }
        }
        public string MostrarDisponibilidad()
        {
            if (disponible)
            {
                return "Disponible";
            }
            else
            {
                return "No se encuentra disponible actualmente";
            }
        }
        public double Conversion()
        {
            return precio / tipoCambioDolar;
        }
        public string MostrarInformacion()
        {
            return $"Marca: {marca}. \nModelo: {modelo}. \nPrecio de venta: Q{precio}. \nPrecio en dólares: ${Conversion()}. \nDisponibilidad: {MostrarDisponibilidad()}.";
        }
        public void AplicarDescuento(double miDescuento)
        {
            descuentoAplicado = miDescuento;
            double precioNuevo = precio - descuentoAplicado;
            precio = precioNuevo;
        }
    }
}