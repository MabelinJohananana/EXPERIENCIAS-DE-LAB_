﻿7namespace L9_ts_MJCR_1027823
{
    partial class UserControl1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Datos_ingr = new System.Windows.Forms.TabPage();
            this.BTN_info = new System.Windows.Forms.Button();
            this.TXT_tcambio = new System.Windows.Forms.TextBox();
            this.TXT_marca = new System.Windows.Forms.TextBox();
            this.TXT_precio = new System.Windows.Forms.TextBox();
            this.TXT_modelo = new System.Windows.Forms.TextBox();
            this.LBL_tcambio = new System.Windows.Forms.Label();
            this.LBL_marca = new System.Windows.Forms.Label();
            this.LBL_precio = new System.Windows.Forms.Label();
            this.LBL_modelo = new System.Windows.Forms.Label();
            this.Datos_auto = new System.Windows.Forms.TabPage();
            this.BTN_cambiar_dis = new System.Windows.Forms.Button();
            this.BTN_aplicar = new System.Windows.Forms.Button();
            this.TXT_descuento = new System.Windows.Forms.TextBox();
            this.LBL_descuento = new System.Windows.Forms.Label();
            this.BTN_limpiar = new System.Windows.Forms.Button();
            this.BTN_salir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.Datos_ingr.SuspendLayout();
            this.Datos_auto.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Datos_ingr);
            this.tabControl1.Controls.Add(this.Datos_auto);
            this.tabControl1.Location = new System.Drawing.Point(220, 72);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(347, 329);
            this.tabControl1.TabIndex = 0;
            // 
            // Datos_ingr
            // 
            this.Datos_ingr.Controls.Add(this.BTN_info);
            this.Datos_ingr.Controls.Add(this.TXT_tcambio);
            this.Datos_ingr.Controls.Add(this.TXT_marca);
            this.Datos_ingr.Controls.Add(this.TXT_precio);
            this.Datos_ingr.Controls.Add(this.TXT_modelo);
            this.Datos_ingr.Controls.Add(this.LBL_tcambio);
            this.Datos_ingr.Controls.Add(this.LBL_marca);
            this.Datos_ingr.Controls.Add(this.LBL_precio);
            this.Datos_ingr.Controls.Add(this.LBL_modelo);
            this.Datos_ingr.Location = new System.Drawing.Point(4, 25);
            this.Datos_ingr.Name = "Datos_ingr";
            this.Datos_ingr.Padding = new System.Windows.Forms.Padding(3);
            this.Datos_ingr.Size = new System.Drawing.Size(339, 300);
            this.Datos_ingr.TabIndex = 0;
            this.Datos_ingr.Text = "Ingreso de datos";
            this.Datos_ingr.UseVisualStyleBackColor = true;
            // 
            // BTN_info
            // 
            this.BTN_info.Location = new System.Drawing.Point(140, 213);
            this.BTN_info.Name = "BTN_info";
            this.BTN_info.Size = new System.Drawing.Size(105, 50);
            this.BTN_info.TabIndex = 8;
            this.BTN_info.Text = "Guardar Información";
            this.BTN_info.UseVisualStyleBackColor = true;
            this.BTN_info.Click += new System.EventHandler(this.BTN_info_Click);
            // 
            // TXT_tcambio
            // 
            this.TXT_tcambio.Location = new System.Drawing.Point(179, 156);
            this.TXT_tcambio.Name = "TXT_tcambio";
            this.TXT_tcambio.Size = new System.Drawing.Size(100, 22);
            this.TXT_tcambio.TabIndex = 7;
            // 
            // TXT_marca
            // 
            this.TXT_marca.Location = new System.Drawing.Point(180, 113);
            this.TXT_marca.Name = "TXT_marca";
            this.TXT_marca.Size = new System.Drawing.Size(100, 22);
            this.TXT_marca.TabIndex = 6;
            // 
            // TXT_precio
            // 
            this.TXT_precio.Location = new System.Drawing.Point(180, 84);
            this.TXT_precio.Name = "TXT_precio";
            this.TXT_precio.Size = new System.Drawing.Size(100, 22);
            this.TXT_precio.TabIndex = 5;
            // 
            // TXT_modelo
            // 
            this.TXT_modelo.Location = new System.Drawing.Point(180, 50);
            this.TXT_modelo.Name = "TXT_modelo";
            this.TXT_modelo.Size = new System.Drawing.Size(100, 22);
            this.TXT_modelo.TabIndex = 4;
            // 
            // LBL_tcambio
            // 
            this.LBL_tcambio.AutoSize = true;
            this.LBL_tcambio.Location = new System.Drawing.Point(73, 162);
            this.LBL_tcambio.Name = "LBL_tcambio";
            this.LBL_tcambio.Size = new System.Drawing.Size(105, 16);
            this.LBL_tcambio.TabIndex = 3;
            this.LBL_tcambio.Text = "Tipo de cambio:";
            // 
            // LBL_marca
            // 
            this.LBL_marca.AutoSize = true;
            this.LBL_marca.Location = new System.Drawing.Point(74, 120);
            this.LBL_marca.Name = "LBL_marca";
            this.LBL_marca.Size = new System.Drawing.Size(45, 16);
            this.LBL_marca.TabIndex = 2;
            this.LBL_marca.Text = "Marca";
            // 
            // LBL_precio
            // 
            this.LBL_precio.AutoSize = true;
            this.LBL_precio.Location = new System.Drawing.Point(74, 91);
            this.LBL_precio.Name = "LBL_precio";
            this.LBL_precio.Size = new System.Drawing.Size(46, 16);
            this.LBL_precio.TabIndex = 1;
            this.LBL_precio.Text = "Precio";
            // 
            // LBL_modelo
            // 
            this.LBL_modelo.AutoSize = true;
            this.LBL_modelo.Location = new System.Drawing.Point(74, 57);
            this.LBL_modelo.Name = "LBL_modelo";
            this.LBL_modelo.Size = new System.Drawing.Size(53, 16);
            this.LBL_modelo.TabIndex = 0;
            this.LBL_modelo.Text = "Modelo";
            this.LBL_modelo.Click += new System.EventHandler(this.label1_Click);
            // 
            // Datos_auto
            // 
            this.Datos_auto.Controls.Add(this.textBox1);
            this.Datos_auto.Controls.Add(this.BTN_cambiar_dis);
            this.Datos_auto.Controls.Add(this.BTN_aplicar);
            this.Datos_auto.Controls.Add(this.TXT_descuento);
            this.Datos_auto.Controls.Add(this.LBL_descuento);
            this.Datos_auto.Location = new System.Drawing.Point(4, 25);
            this.Datos_auto.Name = "Datos_auto";
            this.Datos_auto.Padding = new System.Windows.Forms.Padding(3);
            this.Datos_auto.Size = new System.Drawing.Size(339, 300);
            this.Datos_auto.TabIndex = 1;
            this.Datos_auto.Text = "Datos automovil";
            this.Datos_auto.UseVisualStyleBackColor = true;
            // 
            // BTN_cambiar_dis
            // 
            this.BTN_cambiar_dis.Location = new System.Drawing.Point(100, 241);
            this.BTN_cambiar_dis.Name = "BTN_cambiar_dis";
            this.BTN_cambiar_dis.Size = new System.Drawing.Size(154, 34);
            this.BTN_cambiar_dis.TabIndex = 4;
            this.BTN_cambiar_dis.Text = "Cambiar disponibilidad";
            this.BTN_cambiar_dis.UseVisualStyleBackColor = true;
            // 
            // BTN_aplicar
            // 
            this.BTN_aplicar.Location = new System.Drawing.Point(215, 46);
            this.BTN_aplicar.Name = "BTN_aplicar";
            this.BTN_aplicar.Size = new System.Drawing.Size(75, 23);
            this.BTN_aplicar.TabIndex = 2;
            this.BTN_aplicar.Text = "Aplicar";
            this.BTN_aplicar.UseVisualStyleBackColor = true;
            this.BTN_aplicar.Click += new System.EventHandler(this.BTN_aplicar_Click);
            // 
            // TXT_descuento
            // 
            this.TXT_descuento.Location = new System.Drawing.Point(52, 46);
            this.TXT_descuento.Name = "TXT_descuento";
            this.TXT_descuento.Size = new System.Drawing.Size(100, 22);
            this.TXT_descuento.TabIndex = 1;
            // 
            // LBL_descuento
            // 
            this.LBL_descuento.AutoSize = true;
            this.LBL_descuento.Location = new System.Drawing.Point(49, 27);
            this.LBL_descuento.Name = "LBL_descuento";
            this.LBL_descuento.Size = new System.Drawing.Size(72, 16);
            this.LBL_descuento.TabIndex = 0;
            this.LBL_descuento.Text = "Descuento";
            // 
            // BTN_limpiar
            // 
            this.BTN_limpiar.Location = new System.Drawing.Point(659, 253);
            this.BTN_limpiar.Name = "BTN_limpiar";
            this.BTN_limpiar.Size = new System.Drawing.Size(75, 23);
            this.BTN_limpiar.TabIndex = 1;
            this.BTN_limpiar.Text = "Limpiar";
            this.BTN_limpiar.UseVisualStyleBackColor = true;
            // 
            // BTN_salir
            // 
            this.BTN_salir.Location = new System.Drawing.Point(659, 298);
            this.BTN_salir.Name = "BTN_salir";
            this.BTN_salir.Size = new System.Drawing.Size(75, 23);
            this.BTN_salir.TabIndex = 2;
            this.BTN_salir.Text = "Salir";
            this.BTN_salir.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(260, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 44);
            this.label1.TabIndex = 3;
            this.label1.Text = "LABORATORIO CON CLASES";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(52, 90);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(238, 134);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTN_salir);
            this.Controls.Add(this.BTN_limpiar);
            this.Controls.Add(this.tabControl1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.ResumeLayout(false);
            this.Datos_ingr.ResumeLayout(false);
            this.Datos_ingr.PerformLayout();
            this.Datos_auto.ResumeLayout(false);
            this.Datos_auto.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Datos_ingr;
        private System.Windows.Forms.TabPage Datos_auto;
        private System.Windows.Forms.Label LBL_modelo;
        private System.Windows.Forms.Button BTN_info;
        private System.Windows.Forms.TextBox TXT_tcambio;
        private System.Windows.Forms.TextBox TXT_marca;
        private System.Windows.Forms.TextBox TXT_precio;
        private System.Windows.Forms.TextBox TXT_modelo;
        private System.Windows.Forms.Label LBL_tcambio;
        private System.Windows.Forms.Label LBL_marca;
        private System.Windows.Forms.Label LBL_precio;
        private System.Windows.Forms.Button BTN_aplicar;
        private System.Windows.Forms.TextBox TXT_descuento;
        private System.Windows.Forms.Label LBL_descuento;
        private System.Windows.Forms.Button BTN_limpiar;
        private System.Windows.Forms.Button BTN_salir;
        private System.Windows.Forms.Button BTN_cambiar_dis;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
    }
}
