﻿class Program
{
    static void Main(string[] args)
    {
        //colocarle un valor a cada variable
        double numero1;
        double positivo;
        double negativo;
        double cero;


        Console.WriteLine("Ejercicio 1 ");

        //ingresar números
        Console.WriteLine("Ingrese el numero uno; ");
        numero1 = Convert.ToDouble(Console.ReadLine());
        if (numero1 == positivo)
        {
            Console.WriteLine("\n" + numero1);

            {
            else if (numero1 == negativo)
            }
            Console.WriteLine("\-n" + numero1);
        }
        else if (numero1 == 0)

            Console.WriteLine("\nEl numero es cero");
    }
}











   
