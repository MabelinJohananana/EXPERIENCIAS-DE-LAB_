﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Tiendamas
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            int can = 0, metodo = 0, puntos = 0, fa = 0, can2 = 0, canaz = 0, cana = 0, cang = 0, canco = 0, canc = 0, prov = 0, pg = 0, x = 0;
            double azu = 10.80, arro = 3.80, gama=1.10,coca=17.00,cafe=50.00, su= 0.00,div = 0;
            double razu = 0.00, rarro = 0.00, rgama =0.00, rcoca = 0.00, rcafe = 0.00;
           
            string o,pro,sig;

            for (int i = 0; i <= 3;i++)
            {
                
               
                if (i==1)
                    do
                    {
                        canaz = 0;
                        cana= 0;
                        cang = 0;
                        canco = 0;
                        canc = 0;
                        razu= 0;
                        rarro=0;
                        rgama = 0;
                        rcoca = 0;
                        rcafe = 0;
                        x = 0;
                        puntos = 0;
                        su = 0;

                        Console.Clear();
                        Console.WriteLine("Ingreso a la opción de facturación");

                        Console.WriteLine("Nombre de la factura");
                        String nombre = Console.ReadLine();
                        Console.WriteLine("Ingrese NIT");
                        float NIT = Convert.ToInt64(Console.ReadLine());

                        while (NIT > 1000000000 || NIT < 99999999)
                        {
                            Console.WriteLine("Ingreso mal el NIT, por favor ingreso correctamente");
                            NIT = Convert.ToInt64(Console.ReadLine());
                        }
                        Console.Clear();
                        do
                        {
                            Console.WriteLine("Ingrese el codigo de producto");
                            pro = Console.ReadLine();
                            while (pro != "001" && pro != "002" && pro != "003" && pro != "004" && pro != "005")
                            {
                                Console.WriteLine("Ingreso un valor erroneo, por favor ingrese un dato solicitado");
                                pro = Console.ReadLine();
                            }
                            switch (pro)
                            {
                                case "001":
                                    Console.WriteLine("Ingreso a libra de azúcar, vale por libra: " + azu);

                                    Console.WriteLine("Ingrese la cantidad que se llevara del producto");
                                    canaz = Convert.ToInt32(Console.ReadLine());

                                    razu = canaz * azu;

                                    break;
                                case "002":
                                    Console.WriteLine("Ingreso a libra de arroz, vale por libra: " + arro);

                                    Console.WriteLine("Ingrese la cantidad que se llevara del producto");
                                    cana = Convert.ToInt32(Console.ReadLine());

                                    rarro = cana * arro;
                                    break;
                                case "003":
                                    Console.WriteLine("Ingreso a galletas Gama, vale por unidad: " + gama);

                                    Console.WriteLine("Ingrese la cantidad que se llevara del producto");
                                    cang = Convert.ToInt32(Console.ReadLine());

                                    rgama = cang * gama;

                                    break;
                                case "004":
                                    Console.WriteLine("Ingreso a coca cola, vale por unidad " + coca);

                                    Console.WriteLine("Ingrese la cantidad que se llevara del producto");
                                    canco = Convert.ToInt32(Console.ReadLine());

                                    rcoca = canco * coca;

                                    break;
                                case "005":
                                    Console.WriteLine("Ingreso a libra de café, vale por libra: " + cafe);

                                    Console.WriteLine("Ingrese la cantidad que se llevara del producto");
                                    canc = Convert.ToInt32(Console.ReadLine());

                                    rcafe = canc * cafe;
                                    break;

                            }
                            Console.Clear();
                            can2 = canaz + cana + cang + canco + canc;
                            Console.WriteLine("Desea agregrar mas productos S/N");
                            o = Console.ReadLine();
                            
                            while (o != "S" && o != "N")
                            {
                                Console.WriteLine("Ingreso un valor erroneo, por favor ingrese un dato solicitado");
                                o = Console.ReadLine();
                            }
                            Console.Clear();
                            su = razu + rarro + rgama + rcoca + rcafe;
                        } while (o == "S");

                        Console.WriteLine("Elija la opcion\n No.1 si su método depago es tarjeta de crédito \n No.2 si su método depago es tarjeta de debito \n No.3 si su método depago es efectivo ");
                        metodo = Convert.ToInt32(Console.ReadLine());

                        while (metodo >= 4 && metodo <= 0)
                        {
                            Console.WriteLine("Igreso un dato incorrecto, por favor elija nuervamente la opción");
                        }


                        if (su <= 50)
                        {
                            div = su / 10;
                            puntos = (int)Math.Round(div);

                            
                        }
                        if (su > 50 && su <= 100)
                        {
                            div = su / 10;

                            x = (int)Math.Round(div);
                            puntos = x * 2;


                        }
                        if (su > 100)
                        {
                            div = su / 10;

                            x = (int)Math.Round(div);
                            puntos = x * 3;

                        }

                        pg = pg + puntos ;

                        fa++;
                        Console.Clear();
                        Console.WriteLine("Tienda MASS-URL  123456789");
                        Console.WriteLine(DateTime.Now);
                        Console.WriteLine("Número de factura es: " + fa);
                        Console.WriteLine("Nit: " + NIT + " " + nombre);
                        Console.WriteLine("Lista de productos");
                        if (razu > 0)
                        {
                            Console.WriteLine("\nAzucár\ncantidad de: " + canaz + "\nprecio unitario es: " + azu + " \ncantidad ha pagar por el producto: " + razu);

                        }
                        if (rarro > 0)
                        {
                            Console.WriteLine("\nArroz\ncantidad de: " + cana + "\nprecio unitario es: " + arro + " \ncantidad ha pagar por el producto: " + rarro);
                        }
                        if (rgama > 0)
                        {
                            Console.WriteLine("\nGAMA\ncantidad de: " + cang + " \nprecio unitario de: " + gama + " \ncantidad ha pagar por el producto: " + rgama);
                        }
                        if (rcoca > 0)
                        {
                            Console.WriteLine("\nCoca Cola\ncantidad de: " + canco + "\nprecio unitario de: " + coca + "\ncantidad ha pagar por el producto: " + rcoca);
                        }
                        if (rcafe > 0)
                        {
                            Console.WriteLine("\ncafé\ncantidad de: " + canc + " \nprecio unitario de: " + cafe + " \ncantidad ha pagar por el producto: " + rcafe);
                        }
                        if (can2 == 1)
                        {
                            Console.WriteLine("\nLleva una cantidad de " + can2 + " producto con un valor total de: " + su);
                        }
                        if (can2 > 1)
                        {
                            Console.WriteLine("\nLleva una cantidad de " + can2 + " productos con un valor total de " + su);
                        }
                        prov = prov + can2;
                        
                        Console.ReadKey();
                        Console.Clear();
                        Console.WriteLine("Desea ingrear otra factura S/N");
                        sig=Console.ReadLine();
                       
                    } while (sig=="S") ;
                    
                if (i == 2)
                {
                   Console.Clear();
                   Console.WriteLine("Elijio reportes de factorización");

                   Console.WriteLine("\nTotal de facturas echas: " + fa);
                   Console.WriteLine("\nTotal de productos vendidos: " + prov);
                   Console.WriteLine("\nTotal de puntos: " + pg);
                }
                if(i == 3) 
                { 
                    Console.WriteLine("Elijio salir del programa");
                }
            }
            Console.ReadKey();
        }

    }
        
}

