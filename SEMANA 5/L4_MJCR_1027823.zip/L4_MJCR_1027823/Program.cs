﻿class Program
{
    static void Main(string[] args)
    {
        //colocarle un valor a cada variable
        double numero1;
        double numero2;
        double numero3;
        double suma;
        double multi;
        double resta;
        double división;
        double div;
        double mod;

        Console.WriteLine("Ejercicio 1; Operaciones Aritmeticas \n");

        //ingresar números
        Console.WriteLine("Ingrese el primer número; ");
        numero1 = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Ingrese el segundo número: ");
        numero2 = Convert.ToDouble(Console.ReadLine());

        // se realizan las operaciones

        suma = numero1 + numero2;
        resta = numero1 - numero2;
        multi = numero1 * numero2;
        división = numero1 / numero2;
        div = numero1 / numero2;
        mod = numero1 % numero2;

        // muestra de resultado de las operaciones 

        Console.WriteLine("\n" + numero1 + " + " + numero2 + " = " + suma);
        Console.WriteLine(numero1 + " - " + numero2 + " = " + resta);
        Console.WriteLine(numero1 + " * " + numero2 + " = " + multi);
        Console.WriteLine(numero1 + " / " + numero2 + " = " + división);
        Console.WriteLine(numero1 + " / " + numero2 + " = " + div);
        Console.WriteLine(numero1 + " % " + numero2 + " = " + mod);

        // Se agrega un mensaje

        Console.WriteLine("");
        Console.WriteLine("\n\nEjercicio 2: Operaciones Booleanas");

        if (numero1 > numero2)
        {
            Console.WriteLine("\n" + numero1 + " > " + numero2);

        }
        else if (numero1 < numero2)
        {
            Console.WriteLine("\n" + numero1 + " < " + numero2);

        }
        else if (numero1 == numero2)
        {
            Console.WriteLine("\nAmbos Numeros son iguales");

        }
    }
}


